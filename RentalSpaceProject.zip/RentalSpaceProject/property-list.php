<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Please log in first!'); window.location = 'login.php';</script>";
    exit;
}

// Include database connection
include('connect.php');

// Get the logged-in user's email
$logged_in_email = $_SESSION['email'];

// Fetch properties associated with the logged-in user
$sql = "SELECT * FROM property_posts WHERE email = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("s", $logged_in_email);
$stmt->execute();
$result = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Listings</title>
    <link rel="stylesheet" href="propertylist.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;

            /* Add your image URL here */
            background-size: cover;
            background-position: center center;
            background-attachment: fixed;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;

            /* Optional: add image here */
            background-size: cover;
            background-position: center center;
            background-attachment: fixed;
            padding: 20px;
            border-radius: 10px;
            background-color: rgba(255, 255, 255, 0.7);
            /* Optional: to create a slight overlay for better readability */
        }

        h1 {
            text-align: center;
            color: red;
            margin-bottom: 20px;
        }

        .property-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 20px;
        }

        .property-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
            flex: 1 1 calc(33.333% - 20px);
            max-width: calc(33.333% - 20px);
        }

        .property-card:hover {
            transform: translateY(-5px);
        }

        .property-image img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .property-details {
            padding: 15px;
        }

        .property-details h2 {
            font-size: 20px;
            margin: 0;
            color: #444;
        }

        .property-details p {
            margin: 10px 0;
            color: #555;
        }

        .button-container {
            margin-top: 15px;
            text-align: center;
        }

        .btn {
            padding: 10px 20px;
            font-weight: bold;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100px;
        }

        .btn-danger {
            background-color: red;
        }

        .btn-danger:hover {
            background-color: darkred;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 style="text-align:center">My Property Listings</h1>
        <div class="property-list">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="property-card">
                        <div class="property-image">
                            <?php if (!empty($row['image1'])): ?>
                                <img src="<?php echo htmlspecialchars($row['image1']); ?>" alt="Property Image">
                            <?php else: ?>
                                <img src="default-property.jpg" alt="Default Image">
                            <?php endif; ?>
                        </div>

                        <div class="property-details">
                            <h2>
                                <?php echo $row['property_name']; ?>
                            </h2>
                            <p><strong>Price:</strong> ₹
                                <?php echo number_format($row['property_price']); ?>
                            </p>
                            <p><strong>Address:</strong>
                                <?php echo $row['property_address']; ?>
                            </p>
                            <p><strong>City:</strong>
                                <?php echo $row['city']; ?>
                            </p>
                            <p><strong>State:</strong>
                                <?php echo $row['state']; ?>
                            </p>
                            <p><strong>BHK:</strong>
                                <?php echo $row['bhk']; ?>
                            </p>
                            <p><strong>Property Type:</strong>
                                <?php echo $row['property_type']; ?>
                            </p>
                            <div class="button-container">
                                <button class="btn btn-danger" onclick="window.location.href='updateflat.php?id=<?php echo $row['id']; ?>'">Update</button>

                                <button class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this property?') ? window.location.href='delete_property.php?id=<?php echo $row['id']; ?>' : null">Delete</button>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No properties found for your account.</p>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>