<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    echo "<script>alert('You need to log in first!');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

// Fetch the user ID (email) and username from the session
$user_id = $_SESSION['email'];
$username = $_SESSION['username'];

// Include your database connection file
include 'connect.php';

// Prepare and bind the query to count properties
$count_properties = $conn->prepare("SELECT * FROM `property_posts` WHERE email = ?");
$count_properties->bind_param("s", $user_id); // 's' for string parameter
$count_properties->execute();
$result_properties = $count_properties->get_result(); // Get the result of the query
$total_properties = $result_properties->num_rows; // Use num_rows for row count
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Dashboard</title>
    <link rel="stylesheet" href="dashboardstyle.css">
</head>

<body>
    <h1>DASHBOARD</h1>
    <div class="horizontal-container">
        <div class="user-info">

            <p><?php echo htmlspecialchars($user_id); ?></p> <!-- Display email (user_id) -->
            <button class="btn"><a href="profile.php">Update Profile</button>
        </div>
        <div class="property-info">
            <h4>Property Listed</h4>
            <p class="property-count"><?= $total_properties; ?></p>
            <button class="btn"><a href="property-list.php">View All Listings</a></button>
        </div>
    </div>


    <script src="javascript.js"></script>
</body>

</html>