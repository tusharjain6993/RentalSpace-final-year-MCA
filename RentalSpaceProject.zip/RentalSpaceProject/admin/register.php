<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['Name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // Hashing password

    // Debug: Check if data is received correctly
    if (empty($name) || empty($email) || empty($_POST['password'])) {
        die("Error: One or more fields are empty.");
    }

    // Debug: Check if the email is already registered
    $check_stmt = $conn->prepare("SELECT email FROM admin_login WHERE email = ?");
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        die("Error: Email already registered!");
    }
    $check_stmt->close();

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO admin_login (name, email, password) VALUES (?, ?, ?)");

    if (!$stmt) {
        die("SQL Error: " . $conn->error); // Show MySQL error
    }

    $stmt->bind_param("sss", $name, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! You can now log in.');</script>";
        echo "<script>window.location.href = 'admin-dashbaord.php';</script>";
    } else {
        die("Error executing statement: " . $stmt->error); // Show error
    }

    $stmt->close();
    $conn->close();
}
