<?php
session_start();

// Check if admin is logged in (modify this if you have roles)
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Unauthorized access!');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_email = $_POST['user_email'];

    // Delete user's property listings first (to maintain referential integrity)
    $delete_properties = $conn->prepare("DELETE FROM property_posts WHERE email = ?");
    $delete_properties->bind_param("s", $user_email);
    $delete_properties->execute();
    $delete_properties->close();

    // Delete user from database
    $delete_user = $conn->prepare("DELETE FROM users WHERE email = ?");
    $delete_user->bind_param("s", $user_email);

    if ($delete_user->execute()) {
        echo "<script>alert('User and associated properties removed successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting user!');</script>";
    }

    $delete_user->close();
    $conn->close();

    echo "<script>window.location.href = 'dashboard.php';</script>";
    exit();
}
