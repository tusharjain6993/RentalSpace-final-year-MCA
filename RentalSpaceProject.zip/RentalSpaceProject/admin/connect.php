<?php
$servername = "localhost"; // Replace with your DB server
$username = "root";        // Replace with your DB username
$password = "";
$dbname = "login";
// Replace with your DB password


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("connection failed" . $conn->connect_error);
}
