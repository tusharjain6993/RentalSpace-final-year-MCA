<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    echo "<script>alert('You need to log in first!');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

// Fetch the user ID (email) and username from the session
$user_id = $_SESSION['email'];
$username = $_SESSION['username'];

// Include your database connection file
include 'connect.php';

// Fetch all users from the database
$users_query = "SELECT * FROM users";
$users_result = $conn->query($users_query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="dashboardstyle.css">
</head>

<body>
    <h1>DASHBOARD</h1>

    <div class="horizontal-container">
        <div class="user-info">
            <p>Welcome, <?php echo htmlspecialchars($username); ?> (<?php echo htmlspecialchars($user_id); ?>)</p>
            <button class="btn">Update Profile</button>
        </div>
    </div>

    <h2>All Users</h2>
    <table border="1">
        <tr>
            <th>Email</th>
            <th>Username</th>
            <th>Phone</th>
            <th>Registered Date</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $users_result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                <td><?php echo htmlspecialchars($row['registered_at']); ?></td>
                <td>
                    <form action="delete_user.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this user?');">
                        <input type="hidden" name="user_email" value="<?php echo htmlspecialchars($row['email']); ?>">
                        <button type="submit" class="btn-delete">Remove User</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>

    <script src="javascript.js"></script>
</body>

</html>