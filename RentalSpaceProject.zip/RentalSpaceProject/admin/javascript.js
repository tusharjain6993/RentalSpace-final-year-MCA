const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

function toggleAnswer(questionElement) {
    const answerElement = questionElement.nextElementSibling;

    // Toggle visibility of the answer
    answerElement.classList.toggle('active');
    questionElement.classList.toggle('active');

    // Toggle the + and - icon
    const icon = questionElement.querySelector('.toggle-icon');
    icon.textContent = icon.textContent === '+' ? '-' : '+';
}

function redirectToDetails(id, description) {
    // Encode the description to make it URL-safe
    const encodedDescription = encodeURIComponent(description);
    // Redirect to details page with query parameters
    window.location.href = `details.php?id=${id}&description=${encodedDescription}`;
}


// Function to trigger the scroll-in effect for each element
function addScrollEffect() {
    const elements = document.querySelectorAll('.form-container .form-group, .form-container h4, .form-container button');

    elements.forEach((element, index) => {
        setTimeout(() => {
            element.classList.add('scroll-in');
        }, index * 300); // Delay each element's animation by 300ms
    });
}


document.getElementById('loan').addEventListener('click', function () {
    var loanOption = this.value;
    var loanFieldsDiv = document.getElementById('loan-fields');

    if (loanOption === 'yes') {
        // Show the loan details fields when "Yes" is selected
        loanFieldsDiv.style.display = 'block';
    } else {
        // Hide the loan details fields when "No" is selected
        loanFieldsDiv.style.display = 'none';
    }
});




