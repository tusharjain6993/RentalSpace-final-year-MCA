<?php
session_start();
include 'connect.php'; // Database connection

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ensure user is logged in
if (!isset($_SESSION['email'])) {
    die("User is not logged in. Redirecting...");
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_SESSION['email']; // Get email from session
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $state = $_POST['state'];
    $balance = $_POST['balance'];

    // Debug: Print received data
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";

    // Prepare SQL statement
    $sql = "UPDATE users SET name=?, phone=?, gender=?, state=?, balance=? WHERE email=?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ssssis", $name, $phone, $gender, $state, $balance, $email);

    // Execute and check if successful
    if ($stmt->execute()) {
        echo "Profile updated successfully!";
    } else {
        echo "Error updating profile: " . $stmt->error;
    }

    // Debug: Check affected rows
    echo "Rows affected: " . $stmt->affected_rows;

    $stmt->close();
    $conn->close();

    exit(); // Stop script to check output before redirecting
}
