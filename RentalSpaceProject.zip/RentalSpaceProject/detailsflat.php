<?php
session_start();
include('connect.php');

// Get Property Image from URL
$image_name = isset($_GET['image']) ? $_GET['image'] : '';

if (empty($image_name)) {
    die("<script>alert('Invalid Property Image!'); window.location.href='index.php';</script>");
}

// Fetch Property Details Based on Image Name
$stmt = $conn->prepare("SELECT * FROM listing_property_flatsell WHERE image1 = ?");
$stmt->bind_param("s", $image_name);
$stmt->execute();
$result = $stmt->get_result();

// If property is found
if ($result->num_rows > 0) {
    $property = $result->fetch_assoc();
} else {
    die("<script>alert('Property not found!'); window.location.href='index.php';</script>");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($property['property_name']); ?> - Details</title>
    <link rel="stylesheet" href="detailsflat.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div class="property-details">
        <h1><?php echo htmlspecialchars($property['property_name']); ?></h1>

        <!-- Image Slider -->
        <div class="photo-display">
            <img id="mainImage" src="<?php echo $property["image1"]; ?>" alt="Property Image">
        </div>

        <!-- Thumbnail Images -->
        <div class="thumbnails">
            <?php for ($i = 1; $i <= 4; $i++): ?>
                <?php if (!empty($property["image$i"])): ?>
                    <div class="thumbnail" onclick="changeImage(<?php echo $i; ?>)">
                        <img src="<?php echo $property["image$i"]; ?>" alt="Thumbnail Image <?php echo $i; ?>">
                    </div>
                <?php endif; ?>
            <?php endfor; ?>
        </div>


        <!-- Property Information -->
        <div class="info-grid">
            <div class="info-box">

                <p><strong>Price:</strong> ₹<?php echo number_format($property['property_price'], 2); ?></p>
            </div>
            <div class="info-box">

                <p><strong>Address:</strong> <?php echo htmlspecialchars($property['property_address']); ?></p>
            </div>
            <div class="info-box">

                <p><strong>City:</strong> <?php echo htmlspecialchars($property['city']); ?></p>
            </div>
            <div class="info-box">

                <p><strong>State:</strong> <?php echo htmlspecialchars($property['state']); ?></p>
            </div>
            <div class="info-box">

                <p><strong>BHK:</strong> <?php echo htmlspecialchars($property['bhk']); ?></p>
            </div>
            <div class="info-box">

                <p><strong>Type:</strong> <?php echo htmlspecialchars($property['property_type']); ?></p>
            </div>
            <div class="info-box">

                <p><strong>Size:</strong> <?php echo htmlspecialchars($property['property_size']); ?> sqft</p>
            </div>
        </div>

        <!-- Additional Features -->
        <h2 style="margin-top: 20px;">Amenities</h2>
        <div class="info-grid">
            <div class="info-box">

                <p>Lift: <?php echo htmlspecialchars($property['lift']); ?></p>
            </div>
            <div class="info-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-camera" viewBox="0 0 16 16">
                    <path d="M15 12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h1.172a3 3 0 0 0 2.12-.879l.83-.828A1 1 0 0 1 6.827 3h2.344a1 1 0 0 1 .707.293l.828.828A3 3 0 0 0 12.828 5H14a1 1 0 0 1 1 1zM2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4z" />
                    <path d="M8 11a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5m0 1a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7M3 6.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0" />
                </svg>
                <p>Security Guard: <?php echo htmlspecialchars($property['security_guard']); ?></p>
            </div>
            <div class="info-box">
                <i class="fa-solid fa-dumbbell"></i>
                <p>Gym: <?php echo htmlspecialchars($property['gym']); ?></p>
            </div>
            <div class="info-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-p-circle" viewBox="0 0 16 16">
                    <path d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0M5.5 4.002h2.962C10.045 4.002 11 5.104 11 6.586c0 1.494-.967 2.578-2.55 2.578H6.784V12H5.5zm2.77 4.072c.893 0 1.419-.545 1.419-1.488s-.526-1.482-1.42-1.482H6.778v2.97z" />
                </svg>

                <p>Parking Area: <?php echo htmlspecialchars($property['parking_area']); ?></p>
            </div>
            <div class="info-box">
                <i class="fa-solid fa-wifi"></i>
                <p>WiFi: <?php echo htmlspecialchars($property['wifi'] ?? 'No'); ?></p>
            </div>
        </div>
    </div>
    <script>
        function changeImage(index) {
            // Get all the images and thumbnails
            const images = document.querySelectorAll('.thumbnail img');
            const mainImage = document.getElementById('mainImage');

            // Change the main image source based on the thumbnail clicked
            mainImage.src = images[index - 1].src;
        }
    </script>


</body>

</html>