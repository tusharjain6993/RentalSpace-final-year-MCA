<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "login";

// Establish the database connection
$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die('Could not connect: ' . mysqli_connect_error());
}
echo 'Connected successfully<br/>';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data and sanitize it
    $name = htmlspecialchars($_POST['Name'], ENT_QUOTES);
    $email = htmlspecialchars($_POST['email'], ENT_QUOTES);
    $password = $_POST['password']; // Hash the password

    // Prepare and execute the SQL query to insert data
    $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind the parameters
        $stmt->bind_param("sss", $name, $email, $password);

        // Execute the statement
        if ($stmt->execute()) {
            echo '<script>alert("Record inserted successfully")</script>';
            echo '<script>window.location.href="login.php"</script>';
        } else {
            echo '<script>alert("Error inserting record: ' . $stmt->error . '")</script>';
        }

        // Close the statement
        $stmt->close();
    } else {
        echo '<script>alert("Error preparing the query: ' . $conn->error . '")</script>';
    }
}

// Close the database connection
mysqli_close($conn);
