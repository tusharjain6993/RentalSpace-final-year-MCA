<?php
session_start();
include 'connect.php'; // Database connection

// Ensure user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$user_email = $_SESSION['email']; // Fetch email from session

// Fetch user details based on email
$sql = "SELECT * FROM users WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" href="styles.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: white;
            color: red;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            transition: background-color 0.5s ease-in-out;
        }

        .container {
            background-color: red;
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 90%;
            max-width: 450px;
            transform: scale(1);
            transition: transform 0.3s ease-in-out;
        }

        .container:hover {
            transform: scale(1.03);
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            transition: color 0.3s ease-in-out;
        }

        .container:hover h2 {
            color: #fff5f5;
        }

        label {
            display: block;
            margin: 12px 0 6px;
            font-weight: bold;
            font-size: 16px;
            text-align: left;
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 2px solid white;
            border-radius: 6px;
            background: white;
            color: red;
            font-size: 16px;
            transition: border 0.3s ease-in-out, background 0.3s ease-in-out;
        }

        input:focus,
        select:focus {
            border-color: #ffcccc;
            background: #fff5f5;
        }

        button {
            width: 100%;
            background-color: white;
            color: red;
            border: 2px solid red;
            padding: 12px;
            font-size: 18px;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s ease-in-out, color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }

        button:hover {
            background-color: red;
            color: white;
            transform: scale(1.05);
        }

        a {
            display: block;
            margin-top: 18px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease-in-out;
        }

        a:hover {
            color: #ffcccc;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Update Profile</h2>
        <form action="update-profile.php" method="POST">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">

            <label>Full Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>

            <label>Phone:</label>
            <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>

            <label>Gender:</label>
            <select name="gender" required>
                <option value="Male" <?php echo ($user['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo ($user['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                <option value="Other" <?php echo ($user['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
            </select>

            <label>State:</label>
            <input type="text" name="state" value="<?php echo htmlspecialchars($user['state']); ?>" required>

            <label>Balance:</label>
            <input type="number" name="balance" value="<?php echo htmlspecialchars($user['balance']); ?>" required>

            <button type="submit">Update Profile</button>
        </form>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>

</html>