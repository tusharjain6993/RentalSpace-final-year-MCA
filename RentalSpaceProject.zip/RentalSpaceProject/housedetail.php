<?php
include 'connect.php'; // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $email = $_POST['email'];
    $property_id = $_POST['property_id'];
    $property_type = $_POST['property_type'];
    $property_status = $_POST['property_status'];
    $location = $_POST['location'];
    $price = $_POST['price'];
    $size_sqft = $_POST['size_sqft'];
    $bedrooms = $_POST['bedrooms'];
    $bathrooms = $_POST['bathrooms'];
    $floors = $_POST['floors'];
    $balcony = $_POST['balcony'];
    $parking = $_POST['parking'];
    $age_of_property = $_POST['age_of_property'];
    $condition = $_POST['condition'];
    $furnished_status = $_POST['furnished_status'];
    $security = $_POST['security'];
    $nearby_schools = $_POST['nearby_schools'];
    $nearby_hospitals = $_POST['nearby_hospitals'];
    $nearby_market = $_POST['nearby_market'];
    $loan_eligible = $_POST['loan_eligible'];
    $jda_approved = $_POST['jda_approved'];
    $water_supply = $_POST['water_supply'];
    $power_backup = $_POST['power_backup'];
    $parking_space = $_POST['parking_space'];
    $image1 = $_POST['image1'];
    $image2 = $_POST['image2'];
    $image3 = $_POST['image3'];
    $image4 = $_POST['image4'];
    $contact_phone = $_POST['contact_phone'];
    $carpet = $_POST['carpet'];
    $gate_facing_direction = $_POST['gate_facing_direction'];

    // Prepare SQL statement
    $sql = "INSERT INTO house_inspection_factors (
        email, property_id, property_type, property_status, location, price, size_sqft, bedrooms, bathrooms, floors, balcony, 
        parking, age_of_property, condition, furnished_status, security, nearby_schools, nearby_hospitals, nearby_market, 
        loan_eligible, jda_approved, water_supply, power_backup, parking_space, image1, image2, image3, image4, 
        contact_phone, carpet, gate_facing_direction
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sisssdiiiiisssssssssssssisisssss",
        $email,
        $property_id,
        $property_type,
        $property_status,
        $location,
        $price,
        $size_sqft,
        $bedrooms,
        $bathrooms,
        $floors,
        $balcony,
        $parking,
        $age_of_property,
        $condition,
        $furnished_status,
        $security,
        $nearby_schools,
        $nearby_hospitals,
        $nearby_market,
        $loan_eligible,
        $jda_approved,
        $water_supply,
        $power_backup,
        $parking_space,
        $image1,
        $image2,
        $image3,
        $image4,
        $contact_phone,
        $carpet,
        $gate_facing_direction
    );

    if ($stmt->execute()) {
        echo "Record inserted successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
    $sql1 = "INSERT INTO listing_property_housesell (
        email, property_id, property_type, property_status, location, price, size_sqft, bedrooms, bathrooms, floors, balcony, 
        parking, age_of_property, condition, furnished_status, security, nearby_schools, nearby_hospitals, nearby_market, 
        loan_eligible, jda_approved, water_supply, power_backup, parking_space, image1, image2, image3, image4, 
        contact_phone, carpet, gate_facing_direction
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param(
        "sisssdiiiiisssssssssssssisisssss",
        $email,
        $property_id,
        $property_type,
        $property_status,
        $location,
        $price,
        $size_sqft,
        $bedrooms,
        $bathrooms,
        $floors,
        $balcony,
        $parking,
        $age_of_property,
        $condition,
        $furnished_status,
        $security,
        $nearby_schools,
        $nearby_hospitals,
        $nearby_market,
        $loan_eligible,
        $jda_approved,
        $water_supply,
        $power_backup,
        $parking_space,
        $image1,
        $image2,
        $image3,
        $image4,
        $contact_phone,
        $carpet,
        $gate_facing_direction
    );

    if ($stmt->execute()) {
        echo "Record inserted successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
    // Close the statement and connection
    $stmt1->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Posting Form</title>
    <link rel="stylesheet" href="housedetail.css">
</head>

<body>
    <div class="form-container">
        <h2 style="color:red; font-size:40px;text-align: center;">Post Your Property</h2>
        <form method="POST" action="propertypost.php" enctype="multipart/form-data">
            <!-- Property Details -->
            <div class="form-row">
                <div class="form-group">
                    <label for="property-type">Property Type</label>
                    <select id="property-type" name="property-type" style="width:50%;" required>
                        <option value="">Select Property Type</option>
                        <option value="house">House</option>

                    </select>
                </div>

                <div class="form-group">
                    <label for="property-status">Property Status</label>
                    <select id="property-status" name="property-status" style="width:60%;" required>
                        <option value="">Select Property Status</option>
                        <option value="sell">Sale</option>
                        <option value="rent">Rent</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="property-size">Property Size</label>
                    <input style="width:25%;" type="text" id="property-size" name="property-size" placeholder="Square Feet" required>
                </div>
            </div>

            <!-- Property Name, Price and Address -->
            <div class="form-row">
                <div class="form-group">
                    <label for="property-name">Property Name</label>
                    <input type="text" id="property-name" name="property-name" style="width:45%;" required>
                </div>
                <div class="form-group">
                    <label for="property-price">Property Price</label>
                    <input type="text" id="property-price" name="property-price" style="width:60%;" required>
                </div>
            </div>

            <!-- Location Details -->
            <div class="form-row">
                <div class="form-group">
                    <label for="property-address">Property Address</label>
                    <input type="text" id="property-address" name="property-address" style="width:45%;" required>
                </div>
                <div class="form-group">
                    <label for="pincode">Pincode</label>
                    <input type="text" id="pincode" name="pincode" style="width:70%;" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="state">State</label>
                    <select id="state" name="state" style="width:60%;" required>
                        <option value="">Select State</option>
                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                        <option value="Nagaland">Nagaland</option>
                        <option value="Rajasthan">Rajasthan</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="West Bengal">West Bengal</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Delhi">Delhi</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="city">City</label>
                    <select id="city" name="city" required style="width:70%;">
                        <option value="">Select City</option>
                        <option value="Jodhpur">Jodhpur</option>
                        <option value="Jaipur">Jaipur</option>
                        <option value="BharatPur">BharatPur</option>
                        <option value="Alwar">Alwar</option>
                        <option value="Noida">Noida</option>
                        <option value="Gurugram">Gurugram</option>
                        <option value="Ahamdabad">Ahamdabad</option>
                    </select>
                </div>
            </div>

            <!-- Property Details like Bedrooms, Floors, etc. -->
            <div class="form-row">
                <div class="form-group">
                    <label for="bedrooms">Number of Bedrooms</label>
                    <input type="number" id="bedrooms" name="bedrooms" style="width:40%;" required>
                </div>
                <div class="form-group">
                    <label for="floors">Number of Floors</label>
                    <input type="number" id="floors" name="floors" style="width:60%;" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="balcony">Number of Balconies</label>
                    <input type="number" id="balcony" name="balcony" style="width:40%;" required>
                </div>
                <div class="form-group">
                    <label for="roomfloor">Room Floors</label>
                    <input type="number" id="roomfloor" name="roomfloor" style="width:70%;" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="bhk">BHK</label>
                    <select id="bhk" name="bhk" required style="width:60%;">
                        <option value="">Select BHK</option>
                        <option value="1">1 BHK</option>
                        <option value="2">2 BHK</option>
                        <option value="3">3 BHK</option>
                        <option value="4">4 BHK</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="purchase-date">Date When Purchased</label>
                    <input type="date" id="purchase-date" name="purchase-date" style="width:90%;" required>
                </div>
            </div>

            <!-- Services Checkboxes -->
            <h4>Services</h4>
            <div class="services-checkbox">
                <label><input type="checkbox" name="lift" value="yes"> Lift</label>
                <label><input type="checkbox" name="security_guard" value="yes"> Security Guard</label>
                <label><input type="checkbox" name="kids_play_area" value="yes"> Kids Play Area</label>
                <label><input type="checkbox" name="water_supply" value="yes"> 24/7 Water Supply</label>
                <label><input type="checkbox" name="power_backup" value="yes"> Power Backup</label>
                <label><input type="checkbox" name="parking_area" value="yes"> Parking Area</label>
                <label><input type="checkbox" name="gym" value="yes"> Gym</label>
                <label><input type="checkbox" name="shopping_mall" value="yes"> Shopping Mall</label>
                <label><input type="checkbox" name="hospital" value="yes"> Hospital</label>
                <label><input type="checkbox" name="school" value="yes"> School</label>
                <label><input type="checkbox" name="market_area" value="yes"> Market Area</label>
                <label><input type="checkbox" name="cctv" value="yes"> CCTV</label>
            </div>

            <!-- Loan Details -->
            <h4>Loan Details</h4>
            <div class="form-row">
                <div class="form-group">
                    <label for="loan">Loan</label>
                    <select id="loan" name="loan">
                        <option value="">Yes/No</option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="loan-amount">Remaining Loan Amount</label>
                    <input type="text" id="loan-amount" name="loan-amount">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="jda_approved">JDA Approved</label>
                    <input type="text" id="jda_approved" name="jda_approved" required>
                </div>

                <div class="form-group">
                    <label for="furniture-status">Furniture Status</label>
                    <select id="furniture-status" name="furniture-status" required>
                        <option value="">Select Furniture Status</option>
                        <option value="furnished">Furnished</option>
                        <option value="semi-furnished">Semi Furnished</option>
                    </select>
                </div>
            </div>

            <!-- Upload Images -->
            <h4>Upload Images</h4>
            <div class="image-upload">
                <input type="file" name="image1">
                <input type="file" name="image2">
                <input type="file" name="image3">
                <input type="file" name="image4">
            </div>

            <!-- Additional Fields -->
            <div class="form-row">
                <div class="form-group">
                    <label for="contact-phone">Contact Phone</label>
                    <input type="text" id="contact-phone" name="contact-phone" required>
                </div>

                <div class="form-group">
                    <label for="carpet">Carpet Area (in sq.ft.)</label>
                    <input type="number" id="carpet" name="carpet" required>
                </div>

                <div class="form-group">
                    <label for="gate-facing-direction">Gate Facing Direction</label>
                    <select id="gate-facing-direction" name="gate-facing-direction" required>
                        <option value="north">North</option>
                        <option value="south">South</option>
                        <option value="east">East</option>
                        <option value="west">West</option>
                    </select>
                </div>
            </div>

            <div class="form-row-submit">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
</body>

</html>