<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$location_filter = $_GET['location'] ?? '';
$rent_filter = $_GET['rent'] ?? '';
$amenity_filter = $_GET['amenity'] ?? '';

$sql = "SELECT pd.id, pd.name, pd.location, pd.rent, pd.food_availability, pd.contact,
               GROUP_CONCAT(DISTINCT a.amenity_name SEPARATOR ', ') AS amenities,
               GROUP_CONCAT(DISTINCT pi.image_path SEPARATOR ', ') AS images
        FROM pg_details pd
        LEFT JOIN pg_amenities pa ON pd.id = pa.pg_id
        LEFT JOIN amenities a ON pa.amenity_id = a.id
        LEFT JOIN pg_images pi ON pd.id = pi.pg_id
        WHERE 1";

if (!empty($location_filter)) {
    $sql .= " AND pd.location LIKE '%$location_filter%'";
}
if (!empty($rent_filter)) {
    $sql .= " AND pd.rent <= $rent_filter";
}
if (!empty($amenity_filter)) {
    $sql .= " AND a.amenity_name LIKE '%$amenity_filter%'";
}

$sql .= " GROUP BY pd.id";
$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PG Listings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
            padding: 20px;
            text-align: center;
        }

        .search-box {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .search-box input {
            padding: 10px;
            width: 200px;
        }

        .btn-search {
            background-color: #d32f2f;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        .pg-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .pg-card {
            background: white;
            width: 30%;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        .pg-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 5px;
        }

        .pg-card h3 {
            color: #d32f2f;
        }

        .pg-card p {
            font-size: 14px;
        }
    </style>
</head>

<body>
    <h2>PG Listings</h2>
    <div class="search-box">
        <form method="GET">
            <input type="text" name="location" placeholder="Search by Location">
            <input type="number" name="rent" placeholder="Max Rent">
            <input type="text" name="amenity" placeholder="Amenity (WiFi, AC, etc.)">
            <button type="submit" class="btn-search">Search</button>
        </form>
    </div>

    <div class="pg-container">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="pg-card">
                <?php
                $images = !empty($row['images']) ? explode(', ', $row['images']) : [];
                if (!empty($images)) {
                    echo "<img src='{$images[0]}' alt='PG Image'>";
                } else {
                    echo "<img src='placeholder.jpg' alt='No Image'>";
                }
                ?>
                <h3><?= htmlspecialchars($row['name']) ?></h3>
                <p><strong>Location:</strong> <?= htmlspecialchars($row['location']) ?></p>
                <p><strong>Rent:</strong> ₹<?= htmlspecialchars($row['rent']) ?></p>
                <p><strong>Food Available:</strong> <?= htmlspecialchars($row['food_availability']) ?></p>
                <p><strong>Contact:</strong> <?= htmlspecialchars($row['contact']) ?></p>
                <p><strong>Amenities:</strong> <?= htmlspecialchars($row['amenities'] ?? 'None') ?></p>
            </div>
        <?php endwhile; ?>
    </div>
</body>

</html>
<?php $conn->close(); ?>