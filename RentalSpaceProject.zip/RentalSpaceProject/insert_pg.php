<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate form data
$name = $_POST['name'] ?? '';
$location = $_POST['location'] ?? '';
$rent = $_POST['rent'] ?? 0;
$food_availability = $_POST['food_availability'] ?? '';
$contact = $_POST['contact'] ?? '';

if (empty($name) || empty($location) || empty($rent) || empty($food_availability) || empty($contact)) {
    die("All fields are required!");
}

// Image upload handling
$uploaded_images = [];
$target_dir = "uploads/";
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}

foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
    $file_name = basename($_FILES["images"]["name"][$key]);
    $target_file = $target_dir . $file_name;

    if (move_uploaded_file($tmp_name, $target_file)) {
        $uploaded_images[] = $file_name;
    }
}

$images = implode(",", $uploaded_images); // Store image names as a comma-separated string

// Insert data into `pg_details`
$sql = "INSERT INTO pg_details (name, location, rent, food_availability, contact, image) 
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("ssisss", $name, $location, $rent, $food_availability, $contact, $images);

if ($stmt->execute()) {
    echo "PG registered successfully!";
    header("Location: fetch_pg.php");
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PG Listings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #ffffff;
            color: #333;
        }

        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #d32f2f;
            color: white;
            font-size: 18px;
        }

        .image-container {
            display: flex;
            gap: 5px;
        }

        .image-container img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }

        .register-btn {
            background-color: #d32f2f;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: 0.3s;
            border-radius: 5px;
        }

        .register-btn:hover {
            background-color: #b71c1c;
            transform: scale(1.05);
        }
    </style>
</head>

<body>

    <h2>PG Listings</h2>

    <table>
        <thead>
            <tr>
                <th>Images</th>
                <th>Name</th>
                <th>Location</th>
                <th>Rent</th>
                <th>Food Availability</th>
                <th>Contact</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <div class="image-container">
                                <?php
                                $images = explode(",", $row['image']);
                                foreach ($images as $img) {
                                    echo "<img src='uploads/" . htmlspecialchars($img) . "' alt='PG Image'>";
                                }
                                ?>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['location']) ?></td>
                        <td><?= htmlspecialchars($row['rent']) ?></td>
                        <td><?= htmlspecialchars($row['food_availability']) ?></td>
                        <td><?= htmlspecialchars($row['contact']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No PGs found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <br>
    <a href="index.html"><button class="register-btn">Register Another PG</button></a>
    <a href="fetch_pg.php"><button class="register-btn">FETCH</button></a>


</body>

</html>

<?php $conn->close(); ?>