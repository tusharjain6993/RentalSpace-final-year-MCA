<?php
session_start();

// Include database connection
include('connect.php');
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Please log in first!'); window.location = 'login.php';</script>";
    exit;
}
// Fetch properties from listing_property_flatsell
$sql = "SELECT * FROM listing_property_flatsell where property_status = 'rent'";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}
$stmt->execute();
$result = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LUXURY FLATS</title>
    <link rel="stylesheet" href="propertylist.css">
    <link rel="stylesheet" href="listingpropertyflatsell.css">
</head>

<body>
    <div>
        <div class="container">
            <h1 class="page-heading">LUXURY FLATS</h1>
            <div class="form-container">
                <h2>Find Your Perfect Home</h2>
                <form class="property-form">
                    <!-- Enter Location -->
                    <div class="form-row">
                        <label for="location">Enter Location <span>*</span></label>
                        <input type="text" id="location" placeholder="Enter city name" class="form-input">
                    </div>

                    <!-- Property Type and BHK -->
                    <div class="form-row">
                        <div class="form-group">
                            <label for="property-type">Property Type <span>*</span></label>
                            <select id="property-type" class="form-select">
                                <option value="" disabled selected>Select</option>
                                <option value="flat">Flat</option>
                                <option value="house">House</option>
                                <option value="shop">Shop</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="bhk">How Many BHK? <span>*</span></label>
                            <select id="bhk" class="form-select">
                                <option value="" disabled selected>Select</option>
                                <option value="1">1 BHK</option>
                                <option value="2">2 BHK</option>
                                <option value="3">3 BHK</option>
                                <option value="4">4 BHK</option>
                                <option value="5">5 BHK</option>
                                <option value="6">6 BHK</option>
                                <option value="7">7 BHK</option>
                                <option value="8">8 BHK</option>
                            </select>
                        </div>
                    </div>

                    <!-- Budget -->
                    <div class="form-row">
                        <div class="form-group">
                            <label for="min-budget">Minimum Budget <span>*</span></label>
                            <select id="min-budget" class="form-select">
                                <option value="" disabled selected>Select</option>
                                <option value="500000">₹5 Lac</option>
                                <option value="1000000">₹10 Lac</option>
                                <option value="2000000">₹20 Lac</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="max-budget">Maximum Budget <span>*</span></label>
                            <select id="max-budget" class="form-select">
                                <option value="" disabled selected>Select</option>
                                <option value="1000000">₹10 Lac</option>
                                <option value="2000000">₹20 Lac</option>
                                <option value="5000000">₹50 Lac</option>
                            </select>
                        </div>
                    </div>

                    <!-- Search Button -->
                    <div class="form-row">
                        <button type="submit" class="search-button">Search Property</button>
                    </div>
                </form>
            </div>

            <div class="property-list">
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div class="property-card">
                            <div class="property-image">
                                <a href="detailsflat.php?image=<?php echo urlencode($row['image1']); ?>">
                                    <?php if (!empty($row['image1'])): ?>
                                        <img src="<?php echo $row['image1']; ?>" alt="Property Image">
                                    <?php else: ?>
                                        <img src="default-property.jpg" alt="Default Image">
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="property-details">
                                <h2><?php echo $row['property_name']; ?></h2>
                                <p><strong>Price:</strong> ₹<?php echo number_format($row['property_price']); ?></p>
                                <p><strong>Address:</strong> <?php echo $row['property_address']; ?></p>
                                <p><strong>City:</strong> <?php echo $row['city']; ?></p>
                                <p><strong>State:</strong> <?php echo $row['state']; ?></p>
                                <p><strong>BHK:</strong> <?php echo $row['bhk']; ?></p>
                                <p><strong>Property Type:</strong> <?php echo $row['property_type']; ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No properties found for your account.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>