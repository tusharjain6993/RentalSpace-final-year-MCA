<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Please log in first!'); window.location = 'login.php';</script>";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    include('connect.php');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get logged-in user's email from the session
    $logged_in_email = $_SESSION['email'];

    // Checkbox values
    $lift = isset($_POST['lift']) ? 'yes' : 'no';
    $security_guard = isset($_POST['security_guard']) ? 'yes' : 'no';
    $kids_play_area = isset($_POST['kids_play_area']) ? 'yes' : 'no';
    $water_supply = isset($_POST['water_supply']) ? 'yes' : 'no';
    $power_backup = isset($_POST['power_backup']) ? 'yes' : 'no';
    $parking_area = isset($_POST['parking_area']) ? 'yes' : 'no';
    $gym = isset($_POST['gym']) ? 'yes' : 'no';
    $shopping_mall = isset($_POST['shopping_mall']) ? 'yes' : 'no';
    $hospital = isset($_POST['hospital']) ? 'yes' : 'no';
    $school = isset($_POST['school']) ? 'yes' : 'no';
    $market_area = isset($_POST['market_area']) ? 'yes' : 'no';
    $cctv = isset($_POST['cctv']) ? 'yes' : 'no';

    // Handle file uploads
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $uploaded_files = [];
    foreach (['image1', 'image2', 'image3', 'image4'] as $image_key) {
        if ($_FILES[$image_key]['error'] == 0) {
            $target_file = $upload_dir . basename($_FILES[$image_key]['name']);
            if (move_uploaded_file($_FILES[$image_key]['tmp_name'], $target_file)) {
                $uploaded_files[] = $target_file;
            } else {
                $uploaded_files[] = null;
            }
        } else {
            $uploaded_files[] = null;
        }
    }

    // Shared data for all queries
    $bind_values = [
        $logged_in_email,
        $_POST['property-type'],
        $_POST['property-status'],
        $_POST['property-size'],
        $_POST['property-name'],
        $_POST['property-price'],
        $_POST['property-address'],
        $_POST['pincode'],
        $_POST['state'],
        $_POST['city'],
        $_POST['bedrooms'],
        $_POST['floors'],
        $_POST['bhk'],
        $_POST['balcony'],
        $_POST['roomfloor'],
        $_POST['purchase-date'],
        $lift,
        $security_guard,
        $kids_play_area,
        $water_supply,
        $power_backup,
        $parking_area,
        $gym,
        $shopping_mall,
        $hospital,
        $school,
        $market_area,
        $cctv,
        $_POST['loan'],
        $_POST['loan_amount'],
        $_POST['jda_approved'],
        $uploaded_files[0],
        $uploaded_files[1],
        $uploaded_files[2],
        $uploaded_files[3],
        $_POST['furniture_status']
    ];

    // Query for `listing_property_flatsell`

    // Query for `flatsell` (only if LuxuryFlat and sell)
    if ($_POST['property-type'] === 'flat' && $_POST['property-status'] === 'sell') {
        $sql2 = "INSERT INTO flatsell (
            email, property_type, property_status, property_size, property_name, property_price, property_address, pincode, state, city, bedrooms, floors, bhk, balcony, room_floor, purchase_date, lift, security_guard, kids_play_area, water_supply, power_backup, parking_area, gym, shopping_mall, hospital, school, market_area, cctv, loan, loan_amount, jda_approved, image1, image2, image3, image4, furniture_status
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param(str_repeat("s", count($bind_values)), ...$bind_values);
        if (!$stmt2->execute()) {
            die("Error inserting into flatsell: " . $conn->error);
        }
        $sql1 = "INSERT INTO listing_property_flatsell (
            email, property_type, property_status, property_size, property_name, property_price, property_address, pincode, state, city, bedrooms, floors, bhk, balcony, room_floor, purchase_date, lift, security_guard, kids_play_area, water_supply, power_backup, parking_area, gym, shopping_mall, hospital, school, market_area, cctv, loan, loan_amount, jda_approved, image1, image2, image3, image4, furniture_status
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        $stmt1 = $conn->prepare($sql1);
        $stmt1->bind_param(str_repeat("s", count($bind_values)), ...$bind_values);
        if (!$stmt1->execute()) {
            die("Error inserting into listing_property_flatsell: " . $conn->error);
        }
    }

    // Query for `property_posts`
    $sql3 = "INSERT INTO property_posts (
            email, property_type, property_status, property_size, property_name, property_price, property_address, pincode, state, city, bedrooms, floors, bhk, balcony, room_floor, purchase_date, lift, security_guard, kids_play_area, water_supply, power_backup, parking_area, gym, shopping_mall, hospital, school, market_area, cctv, loan, loan_amount, jda_approved, image1, image2, image3, image4, furniture_status
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    $stmt3 = $conn->prepare($sql3);
    $stmt3->bind_param(str_repeat("s", count($bind_values)), ...$bind_values);
    if (!$stmt3->execute()) {
        die("Error inserting into property_posts: " . $conn->error);
    }

    // Success message
    echo "<script>alert('Property posted successfully!'); window.location = 'index.php';</script>";

    // Clean up
    $stmt1->close();
    if (isset($stmt2)) {
        $stmt2->close();
    }
    $stmt3->close();
    $conn->close();
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Posting Form</title>
    <link rel="stylesheet" href="propertypost.css">

</head>

<body>
    <div class="form-container">
        <h2 style="color:red; font-size:40px;text-align: center;">Post Your Property</h2>
        <form method="POST" action="propertypost.php" enctype="multipart/form-data">
            <!-- New Divs for Property Type, Status, and Text Input -->
            <div class="form-row">
                <div class="form-group">
                    <label for="property-type">Property Type</label>
                    <select id="property-type" name="property-type" required>
                        <option value="">Select Property Type</option>
                        <option value="house">House</option>
                        <option name="flat" value="flat">Luxury Flat</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="property-status">Property Status</label>
                    <select id="property-status" name="property-status" required>
                        <option value="">Select Property Status</option>
                        <option value="sell">Sale</option>
                        <option value="rent">Rent</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="property-description">Property Size</label>
                    <input type="text" id="property-description" name="property-size" placeholder="Sqt." required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="property-name">Property Name</label>
                    <input type="text" id="property-name" name="property-name" required>
                </div>
                <div class="form-group">
                    <label for="property-price">Property Price</label>
                    <input type="text" id="property-price" name="property-price" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="property-address">Property Address</label>
                    <input type="text" id="property-address" name="property-address" required>
                </div>
                <div class="form-group">
                    <label for="pincode">Pincode</label>
                    <input type="text" id="pincode" name="pincode" required>
                </div>
            </div>


            <div class="form-row">
                <div class="form-group">
                    <label for="state">State</label>
                    <select id="state" name="state" required>
                        <option value="">Select State</option>
                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                        <option value="Nagaland">Nagaland</option>
                        <option value="Rajasthan">Rajasthan</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="West Bengal">West Bengal</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Manipur">Manipur</option>
                        <option value="Goa">Goa</option>
                        <option value="Gujarat">Gujarat</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Jammu & Kashmir">Jammu & Kashmir</option>
                        <option value="Ladakh">Ladakh</option>
                        <option value="Bihar">Bihar</option>
                        <option value="Haryana">Haryana</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="city">City</label>
                    <select id="city" name="city" required>
                        <option value="">Select City</option>
                        <option value="Jodhpur">Jodhpur</option>
                        <option value="Jaipur">Jaipur</option>
                        <option value="BharatPur">BharatPur</option>
                        <option value="Alwar">Alwar</option>
                        <option value="Udaipur">Udaipur</option>
                        <option value="Jaisalmer">Jaisalmer</option>
                        <option value="Kota">Kota</option>
                        <option value="Tijara">Tijara</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="bedrooms">Number of Bedrooms</label>
                    <input type="number" id="bedrooms" name="bedrooms" required>
                </div>
                <div class="form-group">
                    <label for="floors">Number of Floors</label>
                    <input type="number" id="floors" name="floors" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="bedrooms">Balcony</label>
                    <input type="number" id="balcony" name="balcony" required>
                </div>
                <div class="form-group">
                    <label for="floors">Room Floors</label>
                    <input type="number" id="floors" name="roomfloor" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="bhk">BHK</label>
                    <select id="bhk" name="bhk" required>
                        <option value="">Select BHK</option>
                        <option value="1">1 BHK</option>
                        <option value="2">2 BHK</option>
                        <option value="3">3 BHK</option>
                        <option value="4">4 BHK</option>
                        <option value="5">5 BHK</option>
                        <option value="6">6 BHK</option>
                        <option value="7">7 BHK</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="purchase-date">Date When Purchased</label>
                    <input type="date" id="purchase-date" name="purchase-date" required>
                </div>
            </div>

            <h4>Services</h4>
            <div class="services-checkbox">
                <label><input type="checkbox" name="lift" value="yes"> Lift</label>
                <label><input type="checkbox" name="security_guard" value="yes"> Security Guard</label>
                <label><input type="checkbox" name="kids_play_area" value="yes"> Kids Play Area</label>
                <label><input type="checkbox" name="water_supply" value="yes"> 24/7 Water Supply</label>
                <label><input type="checkbox" name="power_backup" value="yes"> Power backup</label>
                <label><input type="checkbox" name="parking_area" value="yes"> Parking Area</label>
                <label><input type="checkbox" name="gym" value="yes"> GYM</label>
                <label><input type="checkbox" name="shopping_mall" value="yes"> Shopping Mall</label>
                <label><input type="checkbox" name="hospital" value="yes"> Hospital</label>
                <label><input type="checkbox" name="school" value="yes"> School</label>
                <label><input type="checkbox" name="market_area" value="yes"> Market Area</label>
                <label><input type="checkbox" name="cctv" value="yes"> CCTV</label>
            </div>

            <h4>Loan Details</h4>
            <div class="form-row">
                <div class="form-group">
                    <label for="loan">Loan</label>
                    <select id="loan" name="loan">
                        <option value="">Yes/No</option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="loan-amount">Remaining Loan Amount</label>
                    <input type="text" id="loan-amount" name="loan-amount">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="property-name">JDA Approved</label>
                    <input style="width:425px; " type="text" id="jda_approved" name="jda_approved" required>
                </div>
                <div class="form-group">
                    <label for="property-status">Furiture Status</label>
                    <select id="furniture-staus" name="furniture-status" required>
                        <option value="">Select Furniture Status</option>
                        <option value="sell">Furnished</option>
                        <option value="rent">SemiFurnished</option>
                    </select>
                </div>
            </div>


            <h4>Upload Images</h4>
            <div class="image-upload">
                <input type="file" name="image1">
                <input type="file" name="image2">
                <input type="file" name="image3">
                <input type="file" name="image4">
            </div>

            <div class="form-row-submit">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
</body>

</html>